<?php
    require('index_top.php');
?>

<?php
    require('index_bottom.php');
?>