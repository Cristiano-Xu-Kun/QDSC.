<html>
    <head>
        <title>Global Soccer News</title>
    </head>
    <body>

        <h1>Mesut Ozil: Reaction in Germany - criticism from some, sympathy from others</h1>
        <p> Ehrenfeld is a part of Cologne, Germany, renowned for its multi-cultural community. Senol, working behind the till at one newsagents by the train station, represents just that.<br /><br />

            About half a century ago, his family uprooted from Turkey and came to Germany as guest workers after a labour shortage. Some 60 miles up the road in Gelsenkirchen, the grandparents of Mesut Ozil did the same.<br /><br />

            Senol, a former bodyguard, says he loves interacting with people and happily banters with his customers. "You sure you want the poisonous ones?" he says wryly to one who wants a pack of cigarettes.<br /><br />

            Out the front stand the daily newspapers, not just from Germany but from Turkey too. On the front of almost all of them on Monday was a headline about Ozil. In the view of Senol and the locals he chats to, it's not Ozil's fault.<br /><br />

</p>

<?php
echo "<form>
  <input type="hidden" name="uid" value="Anonymous">
  <input type="hidden" name="date" value='".date('Y-m-d H:i:s')."'>
  <textarea name="message"></textarea>
  <button type="submit" name="submit">Comment</button>
</form>";
?>

<h4>Chat With Friends Online:<a href="chat.html">click here</a></h4>

    </body>
</html>
